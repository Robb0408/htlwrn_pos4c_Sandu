﻿using System.Reflection.Metadata.Ecma335;

namespace PA1_Sandu.Logic
{
    public class Order
    {
        public int OrderId { get; set; }
        public required string Customer { get; set; }
        public required string DeliverToCountry { get; set; }
        public required List<Detail> Details { get; set; }

        public static IEnumerable<KeyValuePair<int, int>> RevenuePerId(List<Order> orders)
        {
            return orders
                .ToDictionary(order => order.OrderId, order => order.Details
                    .Sum(detail => detail.PriceEur))
                .OrderByDescending(order => order.Value);
        }

        public static IEnumerable<KeyValuePair<string, int>> RevenuePerCustomer(List<Order> orders, string asc)
        {
            

            var temp = orders
                .GroupBy(order => order.Customer)
                .ToDictionary(group => group.Key, group => group.Sum(o => o.Details
                .Sum(detail => detail.PriceEur)));

            return asc == "--asc" ? 
                temp.OrderBy(group => group.Value) : 
                temp.OrderByDescending(group => group.Value);
                
        }

        public static IEnumerable<KeyValuePair<string, int>> RevenuePerCountry(List<Order> orders)
        {
            return orders
                .GroupBy(order => order.DeliverToCountry)
                .ToDictionary(group => group.Key, group => group
                    .Sum(g => g.Details.Sum(d => d.PriceEur)))
                .OrderByDescending(group => group.Value);
        }
        
        public static int GetTotalRevenue(List<Order> orders)
        {
            return orders.Sum(order => order.Details.Sum(detail => detail.PriceEur));
        }
    }
}