﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA1_Sandu.Logic
{
    public class Detail
    {
        public string Product { get; set; }
        public int Amount { get; set; }
        public int UnitPriceEur { get; set; }
        public int PriceEur { get; set; }
    }
}
